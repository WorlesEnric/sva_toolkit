class Ebmc < Formula
  desc "Model Checker for SystemVerilog"
  homepage "https://www.cprover.org/ebmc/"
  url "https://github.com/diffblue/hw-cbmc.git",
    tag: "ebmc-5.8",
    revision: "e67715256cd4ac967545bef1025410f676256f5d"
  version "5.8"
  license "BSD-3-Clause"

  uses_from_macos "flex" => :build
  uses_from_macos "curl" => :build
  depends_on "bison" => :build

  def install
    system "make", "-C", "lib/cbmc/src", "minisat2-download"
    system "make", "-C", "src"
    bin.install "src/ebmc/ebmc"
  end

  test do
    system "make", "-C", "regression/ebmc", "test"
  end
end
